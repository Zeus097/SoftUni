from project.teacher import Teacher


teacher = Teacher()
print(teacher.teach())
print(teacher.sleep())
print(teacher.get_fired())
